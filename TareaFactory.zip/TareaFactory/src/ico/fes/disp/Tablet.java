/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.disp;

import ico.fes.factory.Dispositivos;

/**
 *
 * @author Edgar Vitela
 */
public class Tablet implements Dispositivos {
    
    private String marca;
    private String modelo;
    private float precio;
    private int memoria;

    public Tablet() {
    }

    public Tablet(String marca, String modelo, float precio, int memoria) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.memoria = memoria;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getMemoria() {
        return memoria;
    }

    public void setMemoria(int memoria) {
        this.memoria = memoria;
    }

    @Override
    public String toString() {
        return "Tablet{" + "marca=" + marca + ", modelo=" + modelo + ", precio=" + precio + ", memoria=" + memoria + '}';
    }

    
    
}
