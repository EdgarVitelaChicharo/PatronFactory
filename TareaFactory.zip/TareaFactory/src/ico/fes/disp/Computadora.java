/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.disp;

import ico.fes.factory.Dispositivos;

/**
 *
 * @author Edgar Vitela
 */
public class Computadora implements Dispositivos {
    
    private String marca;
    private String modelo;
    private String sistemaOperativo;
    private float precio;
    private boolean tactil;
    private int memoria;

    public Computadora() {
    }

    public Computadora(String marca, String modelo, String sistemaOperativo, float precio, boolean tactil, int memoria) {
        this.marca = marca;
        this.modelo = modelo;
        this.sistemaOperativo = sistemaOperativo;
        this.precio = precio;
        this.tactil = tactil;
        this.memoria = memoria;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getSistemaOperativo() {
        return sistemaOperativo;
    }

    public void setSistemaOperativo(String sistemaOperativo) {
        this.sistemaOperativo = sistemaOperativo;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public boolean isTactil() {
        return tactil;
    }

    public void setTactil(boolean tactil) {
        this.tactil = tactil;
    }

    public int getMemoria() {
        return memoria;
    }

    public void setMemoria(int memoria) {
        this.memoria = memoria;
    }

    @Override
    public String toString() {
        return "Computadora{" + "marca=" + marca + ", modelo=" + modelo + ", sistemaOperativo=" + sistemaOperativo + ", precio=" + precio + ", tactil=" + tactil + ", memoria=" + memoria + '}';
    }

    
    
}
