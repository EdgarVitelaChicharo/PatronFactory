/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.factory;

import ico.fes.disp.Computadora;
import ico.fes.disp.Smartphone;
import ico.fes.disp.Tablet;

/**
 *
 * @author Edgar Vitela
 */
public class DispositivosFactory {
    public static Dispositivos createDispositivo(int tipo){ //Regresa un tipo SNACK... Acoplamos las clases
        switch (tipo) {
            case Dispositivos.COMPUTADORA_MAC:
                    return new Computadora("APPLE", "IMAC", "macOS", 44240.0f, false, 512);
            case Dispositivos.COMPUTADORA_HP:
                    return new Computadora("HP", "All in One 200 G4", "Windows", 18129.0f, false, 256);
            case Dispositivos.COMPUTADORA_DELL:
                    return new Computadora("DELL", "INSPIRON 3515", "Windows", 21999.0f, true, 512);
            case Dispositivos.SMARTPHONE_IPHONE_13:
                    return new Smartphone("APPLE", "13", "IOS", 24000.0f, 256);
            case Dispositivos.SMARTPHONE_SAMSUNG_A52:
                    return new Smartphone("SAMSUNG", "A52", "Android", 7000.0f, 128);
            case Dispositivos.SMARTPHONE_HUAWEI_P50_PRO:
                    return new Smartphone("HUAWEI", "P50 PRO", "HarmonyOS 2", 24000.0f, 256);
            case Dispositivos.TABLET_SAMSUNG_GALAXY_S8:
                    return new Tablet("SAMSUNG", "GALAXY S8", 21830.0f, 128);
            case Dispositivos.TABLET_IPAD_PRO_11:
                    return new Tablet("APPLE", "IPAD PRO 11", 16000.0f, 126);
            case Dispositivos.TABLET_HUAWEI_MATEPAD_PRO_12:
                    return new Tablet("HUAWEI", "MATEPAD PRO 12", 20000.0f, 256);
                    
                
            default:
                throw new AssertionError();
        }
    }
}
