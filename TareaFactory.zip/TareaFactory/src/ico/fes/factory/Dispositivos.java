/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.factory;

/**
 *
 * @author Edgar Vitela
 */
public interface Dispositivos {
    public static int COMPUTADORA_MAC = 1;
    public static int COMPUTADORA_HP = 2;
    public static int COMPUTADORA_DELL = 3;
    public static int SMARTPHONE_IPHONE_13 = 4;
    public static int SMARTPHONE_SAMSUNG_A52 = 5;
    public static int SMARTPHONE_HUAWEI_P50_PRO = 6;
    public static int TABLET_SAMSUNG_GALAXY_S8 = 7;
    public static int TABLET_IPAD_PRO_11 = 8;
    public static int TABLET_HUAWEI_MATEPAD_PRO_12 = 9;
}
