/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.factory;

import java.util.Scanner;

/**
 *
 * @author Edgar Vitela
 */
public class TestDispFactory {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int eleccion = 0;
        
        //Pintamos el menu
        
        System.out.println("Que deseas comer?: ");
        System.out.println(Dispositivos.COMPUTADORA_MAC + ") Computadora Mac");
        System.out.println(Dispositivos.COMPUTADORA_HP + ") Computadora HP");
        System.out.println(Dispositivos.COMPUTADORA_DELL + ") Computadora DELL");
        System.out.println(Dispositivos.SMARTPHONE_IPHONE_13 + ") IPhone 13");
        System.out.println(Dispositivos.SMARTPHONE_SAMSUNG_A52 + ") Samsung A52");
        System.out.println(Dispositivos.SMARTPHONE_HUAWEI_P50_PRO + ") Huawei P50 Pro");
        System.out.println(Dispositivos.TABLET_SAMSUNG_GALAXY_S8 + ") Samsung Galaxy S8");
        System.out.println(Dispositivos.TABLET_IPAD_PRO_11 + ") IPad Pro 11");
        System.out.println(Dispositivos.TABLET_HUAWEI_MATEPAD_PRO_12 + ") Huawei Matepad Pro 12");
        
        try {
            System.out.print("Elige el numero: ");
            eleccion = teclado.nextInt();
        } catch (Exception e) {
            System.out.println("No capturaste un numero");
        }
        
        Dispositivos garnacha = DispositivosFactory.createDispositivo(eleccion);
        System.out.println(garnacha.toString());
    }
}
